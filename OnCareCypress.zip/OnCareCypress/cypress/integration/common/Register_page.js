import { Given, When, And, Then } from 'cypress-cucumber-preprocessor/steps';

Given(/^navigate to "([^"]*)"$/, (website) => {
    cy.visit(website)
})

// inserting the mail and password credentials
And(/^enter "(.*)" in email field $/, (email) => {
    cy.get('').type(email) //type email selector

})

And(/^enter "(.*)" in password field $/, (password) => {
    cy.get('').type(password)  //type password selector
})

And(/^enter "(.*)" in repeat password field $/, (password) => {
    cy.get('').type(password)  //type repeat password selector
})

When(/^Click on register button$/, ()=> {
  cy.get('').click() //type login button selector

)
Then(/^I verify the appearance of the Msg "([^"]*)"$/, (msg) => {
    cy.log(msg)
    cy.xpath('').contains().should('exist') //enter Msg text selector
})