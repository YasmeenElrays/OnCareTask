import { Given, When, And, Then } from 'cypress-cucumber-preprocessor/steps';

Given(/^navigate to "([^"]*)"$/, (website) => {
    cy.visit(website)
})

// inserting the mail and password credentials
And(/^login as "(.*)" with password "(.*)" $/, (email, password) => {
    cy.get('').type(email) //type email selector
    cy.get('').type(password) //type password selector
})

When(/^Click on login button for "([^"]*)" times $/, (numberOfSubmitting) => {
 for (let i = 0; i < numberOfSubmitting; i++) {
                cy.get('').click() //type login button selector
            }
)

And(/^I verify the appearance of the Msg "([^"]*)"$/, (msg) => {
    cy.log(msg)
    cy.xpath('').contains().should('exist')  //enter Msg text selector
})
Then (/^I should redirect to user table view$/, ()=> {
//assert on the title of the page
  cy.xpath('').contains().should('exist') //type user table title selector
}
)